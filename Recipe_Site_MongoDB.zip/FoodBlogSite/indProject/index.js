var express = require('express');

var app = express();

var session = require('express-session');

const assert = require('assert');

app.use(session(require('./config/express-session-options')));

//set up port than retireve it after
app.set('port',process.env.PORT || 3025);

//var ensureLoggedOn = require('connect-ensure-login').ensureLoggedIn;


//Handlebars setup
    var handlebars = require('express-handlebars').create({
            defaultLayout: 'main',
            helpers: {
                section: function (name, options) {
                    if (!this._sections) this._sections = {};
                    this._sections[name] = options.fn(this);
                    return null;
                },
                urlEncode: function (string) {
                    return encodeURIComponent(string);
                },
                equal: function (lvalue, rvalue, options) {
                    if (arguments.length < 3) throw new Error("Handlebars Helper equal needs 2 parameters");
                    if (lvalue !== rvalue) return options.inverse(this);
                    else return options.fn(this);
                }
            }
        }
    );

//MongoDbsetup
    const MongoClient = require('mongodb').MongoClient;
    const mongoOptions = require('./config/mongodb-options');
    MongoClient.connect(mongoOptions.uri, function(err, db) {
        if(err) {
            console.error("Could not connect to MongoDB: "+err.message);
        } else {
            console.log("Connection to MongoDB succeeded!");
            db.close();
        }
    });

//Starting up andn setting up handlebars and folders we will draw from
    app.engine('handlebars', handlebars.engine);
    app.set('view engine','handlebars');

    app.use(express.static(__dirname+'/static'));

    app.use(express.static('views/Images'));

    app.use(require('body-parser').urlencoded({extended: true}));
    var usersDb = require('./lib/users.js');
    const bcrypt = require('bcryptjs');


//Passport Setup and Calls
    var passport = require('passport')
    , LocalStrategy = require('passport-local').Strategy
    , ensureLoggedIn = require('connect-ensure-login').ensureLoggedIn;

// these serialize / deserialize function put the whole user object into the session.
// see http://www.passportjs.org/docs/configure/ for a better approach when using a database
    passport.serializeUser(function(user, done) {
        done(null, user);
    });
    passport.deserializeUser(function(user, done) {
        done(null, user);
    });

passport.use(new LocalStrategy(function (username, password, done) {
        //done is a callback; expects (error|null, user|false) as its parameters.
        console.log("Attempting local login for " + username);
        MongoClient.connect(mongoOptions.uri, function(err,client) {
            assert.equal(null, err);
            console.log("Connected to MongoDB to register user");
            const db = client.db(mongoOptions.dbName);
            const col = db.collection('users');/* @todo figure out what config file or something should tell me this name */

            //Call made to retrieve username and check if it is located in the database
            usersDb.retrieveByUsername(username).then(function(user){
                assert.equal(null, err);
                //need to check if username or user is a falsy, simply do !user
                if(!user){
                    //send log that username was not found, return done with false inside
                    //program does not crash
                    console.log("Username not found; no document");
                    return done(false, false);
                }
                console.log("Retrieved these users: "+JSON.stringify(user));
                bcrypt.compare(password, user.passhash, function(err, res) {
                    if(res){
                        console.log("Password matches hash");
                        return done(null, user);
                    } // the password matches
                    else {
                        console.log("Password did not match hash.");
                        return done(null, false);
                    }
                });//bcrypt.compare
            }).catch((error)=>done(error, false));//toArray (of collection find...)
        });//mongoClient.connect
    }//function upd
    ));//passport use

// for Google April 3:
    var GoogleStrategy = require('passport-google-oauth20').Strategy;
    const googleConfig = require('./config/authGoog').google;
    passport.use(new GoogleStrategy({
            clientID: googleConfig.client_id,
            clientSecret: googleConfig.client_secret,
            callbackURL: "http://localhost:3000/auth/google/callback"
        },
        function(accessToken, refreshToken, profile, cb) {
            console.log(JSON.stringify(profile));
            var user = {
                username: 'google:'+profile.id,
                name: profile.displayName
            };
            // added email on April 5:
            if (profile.emails && profile.emails[0]) {
                user.email=profile.emails[0].value;
            }
            //User.findOrCreate({ googleId: profile.id }, function (err, user) {
            return cb(null, user);
            //});
        }
    ));

    app.use(passport.initialize());
    app.use(passport.session());

//Main WebPage Functionality and the get calls

    /*var webSite = require('./routes/completePage');
    webSite.handlebars = handlebars;
    webSite.doEnsureLoggedIn = ensureLoggedIn('/auth/login');
    //app.use('./views/creater/createWebPage.handlebars', ensureLoggedOn('/auth/login'), pager);
    app.use(webSite);
    */

    app.get('/', function(req,res, next){
        res.render('home', {users: req.user});
    });

    app.get('/about', function(req,res, next){
        res.render('about');
    });

    app.get('/blog', function(req, res, next){
        res.render('blog');
    });

    app.get('/blogItem', function(req, res, next) {
        res.render('blogItem', {users: req.user});
    });

//Register/ Login Funcitonality
    var regLogRouter = require('./routes/setUpAccount');
    //potentially error when called as app.use('setUpAccount', regLogRouter); -> leades to page error -> just keep simple
    app.use('/auth', regLogRouter);

//Page Generator

    var pager = require('./routes/pageGen');
    pager.handlebars = handlebars;
    pager.doEnsureLoggedIn = ensureLoggedIn('/auth/login');
    //app.use('./views/creater/createWebPage.handlebars', ensureLoggedOn('/auth/login'), pager);
    app.use(pager);


//LogOut Functionality

    /*
    app.get('/auth/logout', function(req, res) {
        console.log('Logged user out');
        req.logout();
        res.redirect('/');
    });
    */
    var logOut = require('./routes/logOut');
    logOut.currSess = session;
    logOut.doEnsureLoggedIn = ensureLoggedIn('/auth/login');
    app.use('/auth', logOut);

//Chat Functionality

    // all requests to /chat/* will be sent to our "router"
    var chatRouter = require('./routes/chat');
    chatRouter.handlebars = handlebars;
    app.use('/chat', chatRouter);

    //Displaying Logged In or Logget Out on Everypage
    /*
    app.doEnsureLogged = ensureLoggedIn('/auth/login');
    app.get('/', function(req,res,next){
            app.doEnsureLogged(req,res,next);},
        function(req,res,next){
            console.log("passing values to nav");
            res.render('/partials/nav', {users: req.username});
        });
        */

//Error Handling for 404 and 500

/**
 * This app.use catches any unknown URLs, giving a 404
 * A URL is unknown if it doesn't match anything we
 * specified previously.
 */
    app.use(function (req, res) {
        //res.type('text/plain');
        res.status(404);
        res.render('404');
    });

/**
 * An app.use callback with FOUR (4) parameters is an
 * error handler; the err is in the first
 * parameter to the function.
 * This lets you gracefully catch errors in your
 * code without crashing your whole application
 */
    app.use(function (err, req, res, next) {
        console.log(err.stack);
        //res.type('text/plain');
        res.status(500); // server error
        res.render("500");
    });

////////// STARTUP
app.listen(app.get('port'), function(){
    console.log('Express started on http://localhost:'+ app.get('port')+'; press Ctrl-C to terminate');
});
