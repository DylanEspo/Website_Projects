module.exports = {
    /**
     * link https://console.developers.google.com/getting-started?showFTMessage=false&pli=1
     */
    google: {
        client_id: '911528452810-h512psiiohc88kp0gv8rt7atugugc67j.apps.googleusercontent.com',
        client_secret: '_waSqYmSX5eWNUs4grgOLdL6'
    }
};