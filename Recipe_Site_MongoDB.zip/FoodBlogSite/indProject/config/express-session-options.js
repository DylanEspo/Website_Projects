/**
 * These properties are the options for express sessions for details s
 * @type {{secret: string, resave: boolean, saveUninitialized: boolean}}
 */
module.exports = {
    secret: 'DylansSecret',
    resave: false,
    saveUninitialized: false

};