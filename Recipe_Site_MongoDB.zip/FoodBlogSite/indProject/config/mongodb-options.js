/**
 * How to connect to MongoDB. CAUTION: url contains password! Do not commit to repository!
 * @type {{url: string, dbName: string}}
 */
module.exports = {
    uri: "mongodb://DylAdmin:Margo0609@webclust0-shard-00-00-0vzsh.mongodb.net:27017,webclust0-shard-00-01-0vzsh.mongodb.net:27017,webclust0-shard-00-02-0vzsh.mongodb.net:27017/finalProject?ssl=true&replicaSet=webClust0-shard-0&authSource=admin",
    db: 'finalProject'
    };