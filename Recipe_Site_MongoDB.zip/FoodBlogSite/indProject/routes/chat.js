/*
 * Move all the chat code to its own Router
 */
var express = require('express');
var router = express.Router();
module.exports = router;

router.messages = []; //new Array();

router.get('/', function (req, res) {
    // before we can render our page, we have to get the template in its precompiled form.
    // express-handlebars does this work asynchronously; the getTemplate function
    // returns a Promise, not the compiled template itself. When a Promise succeeds,
    // functions passed to its .then method will run with the real data (the template)
    router.handlebars.getTemplate('views/partials/chatMessages.handlebars', {precompiled: true}).then(
        function (template) { //okay, so now we have our template and can render the page:
            res.render('chat', {
                messages: router.messages,
                templates: [{name: 'chatMessages', 'template': template}]
            });
        }
    )
});

/**
 * Send messages as JSON within our customary error, data object
 */
router.get('/messages', function(req, res) {
    res.json({error: null, data: {messages: router.messages}});
});

/**
 * Accept a new message via POST
 */
router.post('/messages', function(req, res){
    router.messages.unshift({name: req.body.name, message: req.body.message});
    res.json({error: null, data: null});
});

router.post('/', function(req,res){
    router.messages.unshift({name: req.body.name, message: req.body.message});
    res.redirect(303, req.baseUrl);
});