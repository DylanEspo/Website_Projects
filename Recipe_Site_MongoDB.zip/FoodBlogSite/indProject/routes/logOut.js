const express=require('express');
var router = express.Router();
module.exports = router;

const bcrypt = require('bcryptjs');
const passport = require('passport');
const assert = require('assert');

router.get('/logout', function(req, res, next) {
        router.doEnsureLoggedIn(req,res,next);},
    function(req,res,next){
        res.render('auth/logout', {users: req.user});
});

router.post('/logout',
    function(req, res) {
        console.log("User is logged out");
        req.logOut();
        return res.redirect('/');
    }
);

router.get('/nav')