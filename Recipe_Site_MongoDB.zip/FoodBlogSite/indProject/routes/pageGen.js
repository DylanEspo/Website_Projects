const express = require('express');
const collectionName = "webpageData";
const bcrypt = require('bcryptjs');

const formPostDb = require('../lib/blogPostsStored');
const usersDb = require('../lib/users');
const findOptions = {sort: {timestamp: -1}, limit: 10};

var router = express.Router();
module.exports = router;

const MongoClient = require('mongodb').MongoClient;
const mongoOptions = require('../config/mongodb-options');
const _client = MongoClient.connect(mongoOptions.uri);

//Use this variable to pull data from createWebPage, makes it a lot less complicated than uploading via router.post
var uploadForm = function(req, res, next){
    const titleOfArticle = req.body.titleOfArticle;
    const author = req.body.author;
    const ingredients = req.body.listOfIngredients;
    const utensils = req.body.listOfUtensils;
    const steps = req.body.listOfSteps;

    var webPage = {
        titleOfArticle: titleOfArticle,
        author: author,
        listOfIngredients: ingredients,
        listOfUtensils: utensils,
        listOfSteps: steps
    };
    //upload data into the mongodb database
    formPostDb.create(webPage);
};

//launch createWebPage partial and check if the user is signed in
router.get('/createWebPage', function(req, res, next) {
        router.doEnsureLoggedIn(req,res,next);},
    function(req,res,next){
        res.render('creater/createWebPage', {users: req.user});
});

//pull data from the partial using upload form and redirect it to the home page
router.post('/createWebPage', uploadForm, function (req, res) {
    res.redirect(303, '/');
});

//here we grab revelvant information and pass it our partial genBlogPost, from there we pass it to blogItem
router.get('/archive', function (req, res, next) {
    //console.log(formPostDb.retrieve(null));
    Promise.all([
        router.handlebars.getTemplate('views/partials/genBlogPost.handlebars', {precompiled: true}),
        formPostDb.retrieve(null)
    ]).then(
        results =>
            res.render('archive', {users: req.user, web: results[1],
                templates: [{'name': 'genBlogPost', 'template': results[0]}]
            })
    ).catch(console.error);
    //console.log("Post here");
    //console.log(formPostDb.retrieve(null));
});


router.get('/blog/:title', function (req, res, next) {
    //console.log(formPostDb.retrieve(null));
    Promise.all([
        router.handlebars.getTemplate('views/partials/genBlogPost.handlebars', {precompiled: true}),
        formPostDb.retrieveOne(req.params.title)
    ]).then(
        results =>{
            console.log("Here they are", results[1]);
            res.render('blogItem', {users: req.user, post: results[1],
                templates: [{'name': 'blogy', 'template': results[0]}]
            });
    }
    ).catch(console.error);
    //console.log("Post here");
    //console.log(formPostDb.retrieve(null));
});


/*

//renders the blogItem page that we will pass our data to
router.get('/blog/:title', function(req, res, next) {
    formPostDb.retrieveOne(req.params.title).then(
        post=> {
            console.log("This is the post: " + post);
            res.render('blogItem', post);
        }
    ).catch(console.error);

});

/*
router.get('/blog/:title', userCanEdit(function(req,res){
    formPostDb.updatePostById(req.body.id, req.body.titleOfArticle, req.body.listOfIngredients, req.body.listOfSteps)
        .then(()=>res.json({error: null, data: null}))
        .catch(function(err){
            console.error(err);
            res.status(500).json({error: "Could not edit blog", data: null});
        });

}));
*/

/**
 * Get the messages as json data

router.get('/blogPostStored', function(req,res){
    formPostDb.retrieve(null, function(err, messages) {
        res.json({error: null, data: {
            messages: messages
        }});
    });
});

router.post('/testBlog', uploadForm, function(req,res) {
    res.json({error: null, data: null});
});
 */
/*
function userCanEdit(req,res,next) {
    formPostDb.retrieveById(req.params.id).then(
        function(result){
            //console(result);
            if(result && result.username && req.user.username===result.username){
                return next();
            }
            res.status(403).res.json({error: "Can not modify this message", data:null});
        }
    )
}

router.put('/blog/:title', userCanEdit, function(req,res){
    formPostDb.updatePostById(req.body.id, req.body.message)
        .then(()=>res.json({error: null, data: null}))
        .catch(function(err){
            console.error(err);
            res.status(500).json({error: "Could not edit message", data: null});
        });
});
*/