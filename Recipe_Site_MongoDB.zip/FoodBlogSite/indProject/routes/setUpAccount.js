const BCRYPT = {
    SALT_LENGTH: 8
};
const collectionName = 'users';

const express=require('express');
var router = express.Router();
module.exports = router;

//call to users.js and assign it usersDB
const usersDB = require('../lib/users.js');

const bcrypt = require('bcryptjs');
const passport = require('passport');
const assert = require('assert');

const MongoClient = require('mongodb').MongoClient;
const mongoOptions = require('../config/mongodb-options');
const _client = MongoClient.connect(mongoOptions.uri);

// added Apr 3 for Google:
const config = require('../config/authGoog');

router.get('/login', function (req, res, next) {
    res.render('auth/login', {
        google: config.google
    });
});
router.post('/login',
    passport.authenticate('local', {
        failureRedirect: '/auth/login', // go back to the login page if authentication fails
        successReturnToOrRedirect: '/' //go to home page if no other page set in session.returnTo
    }), //include a backstop function in case authenticate doesn't know what to do:
    function (req, res) {
        console.log("Successful log in");
        res.redirect('/creater/createWebPage');
    }
);

router.get('/register', function(req,res) {
    res.render('auth/register');
});
router.post('/register', function(req,res) {
    const plainPassword = req.body.password;
    /* @todo: make sure password meets rules? */
    const username = req.body.username.trim();
    /* @todo: make sure username is not already taken */
    const email = req.body.email.trim();
    /* @todo: validate email */
    const fname = req.body.fName.trim();

    const lname = req.body.lName.trim();

    bcrypt.hash(plainPassword, BCRYPT.SALT_LENGTH, function(err, hash){
        assert.equal(null, err);
        var user = {
            fName: fname,
            lName: lname,
            email: email,
            username: username,
            passhash: hash
        };
        //shared Promise version of MongClient.connect

        //make call to usersDB by creating user
        usersDB.create(user).
        then(()=>res.redirect(req.baseUrl+'/login')).
        catch(console.error);

        /* callback version also leaks connections
        MongoClient.connect(mongoOptions.uri, function(err,client) {
            assert.equal(null,err);
            console.log("Connected to MongoDB to register user");
            const db = client.db(mongoOptions.dbName);
            db.collection(collectionName).insertOne(user, function(err,r) {
                assert.equal(null, err);
                assert.equal(1, r.insertedCount);
                console.log("Successfully inserted user: "+JSON.stringify(r));
                res.redirect(req.baseUrl+"/login");//
            }); //insert
        }); //mongoClient connect
        */
    }); //bcrypt.hash
}); //post to /register
/*
router.get('/google', function(req,res){
    res.render('auth/googleSignin', {
        google: config.google
    });
});
*/
router.get('/google',
    passport.authenticate('google', { scope: ['profile email'] }));

router.get('/google/callback',
    passport.authenticate('google', { failureRedirect: '/auth/login' }),
    function(req, res) {
        // Successful authentication, redirect home.
        res.redirect('/');
    });
