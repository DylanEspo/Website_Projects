<?php

	$user = 'root';
	$pass = '';
	$db = 'test_np';
	
	$db = new mysqli('localhost', $user, $pass, $db) or die("Unable to connect");

	echo "Great work!";
?>