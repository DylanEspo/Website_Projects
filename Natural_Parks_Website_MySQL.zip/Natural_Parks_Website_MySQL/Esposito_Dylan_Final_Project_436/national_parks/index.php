<?php

//Dylan Esposito

// Set time zone  
date_default_timezone_set('America/New_York');

/****************************************************************************   
Silex Setup:
The following code is necessary for one time setup for Silex 
It uses the appropriate services from Silex and Symfony and it
registers the services to the application.
*****************************************************************************/
// Objects we use directly
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Constraints as Assert;
use Silex\Provider\FormServiceProvider;

// Pull in the Silex code stored in the vendor directory
require_once __DIR__.'/../../silex-files/vendor/autoload.php';

// Create the main application object
$app = new Silex\Application();

// For development, show exceptions in browser
$app['debug'] = true;

// For logging support
$app->register(new Silex\Provider\MonologServiceProvider(), array(
    'monolog.logfile' => __DIR__.'/development.log',
));

// Register validation handler for forms
$app->register(new Silex\Provider\ValidatorServiceProvider());

// Register form handler
$app->register(new FormServiceProvider());

// Register the session service provider for session handling
$app->register(new Silex\Provider\SessionServiceProvider());

// We don't have any translations for our forms, so avoid errors
$app->register(new Silex\Provider\TranslationServiceProvider(), array(
        'translator.messages' => array(),
    ));

// Register the TwigServiceProvider to allow for templating HTML
$app->register(new Silex\Provider\TwigServiceProvider(), array(
        'twig.path' => __DIR__.'/npSite',
    ));

// Change the default layout 
// Requires including boostrap.css
$app['twig.form.templates'] = array('bootstrap_3_layout.html.twig');

/*************************************************************************
 Database Connection and Queries:
 The following code creates a function that is used throughout the program
 to query the MySQL database.  This section of code also includes the connection
 to the database.  This connection only has to be done once, and the $db object
 is used by the other code.

*****************************************************************************/
// Function for making queries.  The function requires the database connection
// object, the query string with parameters, and the array of parameters to bind
// in the query.  The function uses PDO prepared query statements.

function queryDB($db, $query, $params) {
    // Silex will catch the exception
    $stmt = $db->prepare($query);
    $results = $stmt->execute($params);
    $selectpos = stripos($query, "select");
    if (($selectpos !== false) && ($selectpos < 6)) {
        $results = $stmt->fetchAll();
    }
    return $results;
}



// Connect to the Database at startup, and let Silex catch errors
$app->before(function () use ($app) {
    include '../../npConnect.php';
    $app['db'] = $db;
});


// *************************************************************************
 
//Generate results when seraching for parks by state
$app->get('/item/{park_id}', function (Silex\Application $app, $park_id) {
    
    $db = $app['db'];
    //query is based around pulling individual parks by the id given
    $query = "select park_Title, park_state, park_desc, park_weatherInfo, park_url from parks p, parks_mesc g
    	 where g.park_id = p.park_id and
    	 p.park_id = ?";
    	 
    //store result of query in results
    $results = queryDB($db, $query, array($park_id));
    
    // Display results in item page. Generate to item.html.twig page
    return $app['twig']->render('item.html.twig', array(
        'pageTitle' => $results[0]['park_ID'],
        'results' => $results
    ));
});


//Generate results when seraching for events by state
$app->get('/eventResults/{event_id}', function (Silex\Application $app, $event_id) {
    
    $db = $app['db'];
    
    //generate query dependent on the given id, should only return one result.
    $query = "select event_id, event_title, event_date, event_time, event_desc, event_loc, event_url from events  
    	 where 
    	 event_id = ?";
    $results = queryDB($db, $query, array($event_id));
    
    // Display results in the eventsResults page
    return $app['twig']->render('eventResults.html.twig', array(
        'pageTitle' => $results[0]['event_id'],
        'results' => $results
    ));
});

//Used to grab results of campgrounds within a couple states.
$app->get('/campResults/{cg_id}', function (Silex\Application $app, $cg_id) {
    // Create query to get the toy with the given toynum
    $db = $app['db'];
    
    //perform a query that pulls data dependent on the campground id
    $query = "select c.cg_name, p.park_title, c.cg_city, c.cg_desc, c.cg_resDesc, c.cg_city, c.cg_state, c.cg_postal 
     	      from campgrounds c, parks p, camp_at h
     	      where h.cg_id = c.cg_id and h.park_id = p.park_id and
    	 c.cg_id = ?";
    $results = queryDB($db, $query, array($cg_id));
    
    // Display results in the campResults page
    return $app['twig']->render('campResults.html.twig', array(
        'pageTitle' => $results[0]['cg_id'],
        'results' => $results
    ));
});

// *************************************************************************

//calls the findParks page which allows you to search for individual parks, monuments, historical sites by state
$app->match('/findParks', function (Request $request) use ($app) {
    $form = $app['form.factory']->createBuilder('form')
        ->add('search', 'text', array(
            'label' => 'Enter the Desired State Code ',
            'constraints' => array(new Assert\NotBlank())
        ))
        ->getForm();
    //run a handleRequest and check if the forum is valid
    $form->handleRequest($request);
    if ($form->isValid()) {
    	//pull data from the form and then store it in srch string
        $regform = $form->getData();
		$srch = $regform['search'];
		
		// Create prepared query 
        $db = $app['db'];
		$query = "SELECT park_id, park_Title, park_state, park_url from parks where park_state like ?";
		$results = queryDB($db, $query, array('%'.$srch.'%'));
		
        // Display results in findParks page, use twig to render, passing information regarding parks, monuments, etc.
        //pass pageTitle and form results as well.
        return $app['twig']->render('findParks.html.twig', array(
            'pageTitle' => 'U.S. Parks and Recres',
            'form' => $form->createView(),
            'results' => $results
        ));
    }
    
    //render the findParks webpage and pass an empty results in the array
    return $app['twig']->render('findParks.html.twig', array(
        'pageTitle' => 'U.S. Parks and Recres',
        'form' => $form->createView(),
        'results' => ''
    ));
});

//displays results from searching for events
$app->match('/findEvents', function (Request $request) use ($app) {
    $form = $app['form.factory']->createBuilder('form')
        ->add('search', 'text', array(
            'label' => 'Enter a State Code',
            'constraints' => array(new Assert\NotBlank())
        ))
        ->getForm();
    $form->handleRequest($request);
    if ($form->isValid()) {
        $regform = $form->getData();
		$srch = $regform['search'];
		
	//Perform a db query that checks what the assigned park state is 
	//and pull values similar to the value enter as the park state.
        $db = $app['db'];
		$query = "SELECT e.event_id, e.event_title, e.event_date, e.event_loc, p.park_Title, p.park_state
			from events e, parks p, held_at h
			where h.event_id = e.event_id and h.park_code = p.park_id and park_state like ? 
			";
		$results = queryDB($db, $query, array('%'.$srch.'%'));
		
        // Display results in findEvents page
        return $app['twig']->render('findEvents.html.twig', array(
            'pageTitle' => 'Search',
            'form' => $form->createView(),
            'results' => $results
        ));
    }
    // If form box is empty then return an empty results page.
    return $app['twig']->render('findEvents.html.twig', array(
        'pageTitle' => 'findEvents',
        'form' => $form->createView(),
        'results' => ''
    ));
});

$app->match('/findCampgrounds', function (Request $request) use ($app) {
    $form = $app['form.factory']->createBuilder('form')
        ->add('search', 'text', array(
            'label' => 'Search',
            'constraints' => array(new Assert\NotBlank())
        ))
        ->getForm();
    $form->handleRequest($request);
    if ($form->isValid()) {
        $regform = $form->getData();
		$srch = $regform['search'];
		
	//Perform query where given state is within the required states of the campgrounds list.
        $db = $app['db'];
		$query = "SELECT cg_id, cg_name, cg_state FROM campgrounds WHERE cg_state like ?";
		$results = queryDB($db, $query, array('%'.$srch.'%'));
		
        // Display results in findCampgournd page, passing results from query into the apge.
        return $app['twig']->render('findCampgrounds.html.twig', array(
            'pageTitle' => 'Search',
            'form' => $form->createView(),
            'results' => $results
        ));
    }
    // If results are empty, redisplay find campgrounds page
    return $app['twig']->render('findCampgrounds.html.twig', array(
        'pageTitle' => 'Search',
        'form' => $form->createView(),
        'results' => ''
    ));
});


// Home Page

//Deploy the home page here, check if user is avaialable otherwise we just render the homepage
$app->get('/', function () use ($app) {
	if ($app['session']->get('is_user')) {
		$user = $app['session']->get('user');
	}
	else {
		$user = '';
	}
	return $app['twig']->render('homeNP.html.twig', array(
        'user' => $user,
        'pageTitle' => 'Home'));
});



// *************************************************************************

// Run the Application

$app->run();